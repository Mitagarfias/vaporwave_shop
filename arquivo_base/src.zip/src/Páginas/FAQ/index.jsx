import React from 'react'

export default function FAQ() {
  return(
    <div>Cheguei na página de FAQ(Frequently Asked Questions = Perguntas Frequentes)</div>
  )
}
