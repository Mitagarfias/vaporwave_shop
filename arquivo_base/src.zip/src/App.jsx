import "./App.css";
import Rotas from './Rotas';

function App(){
    return(
        <Rotas />
    );
}

export default App;