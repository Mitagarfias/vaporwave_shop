function Hallo(){
    return(
        <h1>Hallo.</h1>
    );
}
export default Hallo;